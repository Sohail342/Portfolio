from django.contrib import admin
from myapp_portfolio.models import Certifications, Projects

admin.site.register(Certifications)
admin.site.register(Projects)
